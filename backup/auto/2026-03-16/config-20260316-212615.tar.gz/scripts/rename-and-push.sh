#!/bin/bash
# 重命名文章并推送

cd /home/admin/.openclaw/workspace/openclaw-monetization-blog/posts

# 重命名文件
echo "📝 重命名文章文件..."

if [ -f "2026-03-14-improved-article.md" ]; then
    mv 2026-03-14-improved-article.md 2026-03-14-ecommerce-service-automation.md
    echo "✅ improved-article.md → ecommerce-service-automation.md"
fi

if [ -f "2026-03-14-ai-data-analysis.md" ]; then
    mv 2026-03-14-ai-data-analysis.md 2026-03-14-data-analysis-automation.md
    echo "✅ ai-data-analysis.md → data-analysis-automation.md"
fi

# 提交并推送
cd /home/admin/.openclaw/workspace/openclaw-monetization-blog

git add posts/*.md
git commit -m "📝 重命名文章文件为主题名称"
git push origin master

echo ""
echo "✅ 完成！"
echo ""
echo "📖 查看:"
echo "https://github.com/pyastar/studyai/tree/main/posts"
